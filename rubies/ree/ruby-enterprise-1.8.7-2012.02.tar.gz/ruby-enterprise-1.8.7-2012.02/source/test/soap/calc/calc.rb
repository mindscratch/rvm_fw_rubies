module CalcService
  def self.add(lhs, rhs)
    lhs + rhs
  end

  def self.sub(lhs, rhs)
    lhs - rhs
  end

  def self.multi(lhs, rhs)
    lhs * rhs
  end

  def self.div(lhs, rhs)
    lhs / rhs
  end
end
