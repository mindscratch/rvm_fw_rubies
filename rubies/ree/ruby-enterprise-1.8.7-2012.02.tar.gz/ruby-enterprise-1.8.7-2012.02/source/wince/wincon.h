
#ifndef _WINCON_H_
#define _WINCON_H_

#define CTRL_C_EVENT        0

#endif
