#ifndef _ASSERT_H_
#define _ASSERT_H_

void assert( int expression );

#endif
